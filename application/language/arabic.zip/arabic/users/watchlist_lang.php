<?php


$lang["text_success"] = ' This Advertise Successfully added to your Watch List !';
$lang["text_error"] = ' You need to login to add this product in your Watch List !';

foreach($lang as $key => $val)
{
	$GLOBALS['language'][$key] = $val;
}






?>