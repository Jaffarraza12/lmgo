<?php

$lang['text_serial'] = ' # '; 
$lang['text_swap_picture'] = 'Pictures'; 
$lang['text_swap_title'] = 'Title '; 
$lang['text_swap_action'] = ' Action '; 
$lang['text_swap_compare'] = ' Compare ';

foreach($lang as $key => $val)
{
	$GLOBALS['language'][$key] = $val;
}

?>