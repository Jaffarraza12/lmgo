<?php


$lang["text_success"] = '  Rating Has been done ';
$lang["text_error"] = ' You need to login to do rating!';

foreach($lang as $key => $val)
{
	$GLOBALS['language'][$key] = $val;
}






?>