<?php

$lang["text_heading"] = ' Reply to this add ';
$lang["text_your_name"] = ' Your Name';
$lang["text_label_name"] = ' Name';
$lang["text_your_email"] = ' Your Email';
$lang["text_label_email"] = ' Email';
$lang["text_your_phone"] = ' Your Phone';
$lang["text_label_name"] = ' Phone';
$lang["text_your_message"] = ' Your Message!';
$lang["text_your_description"] = 'Please enter the 4 letters as they  appear in the image on the left.  ';
$lang["text_your_wantit"] = ' Want it ';
$lang["text_your_or"] = ' OR ';
$lang["text_swapit"] = ' Swap It';
$lang["text_terms"] = " By clicking on 'Want it or Swap it', I agree to the Dubazaaro Terms & Conditions and Privacy Policy ";

foreach($lang as $key => $val)
{
	$GLOBALS['language'][$key] = $val;
}


?>