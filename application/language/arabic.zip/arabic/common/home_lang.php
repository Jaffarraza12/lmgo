<?php


$lang["text_language"] = 'العــربية';
$lang["text_sign_in"] = "Sign In";
$lang["text_dashboard"] = "Dashboard";
$lang["text_fb_connect"] = "Connect";
$lang["text_FAQ"] = "FAQ's";
$lang["text_contact"] = "Contact";
$lang["text_place_add"] = "Place an ad";
$lang["text_cart"] = "Cart";
$lang["text_home"] = "Home";
$lang["text_classified"] = "Classified";
$lang["text_shops"] = "Shops";
$lang["text_realestate"] = "Real Estate";
$lang["text_jobs"] = "Jobs";
$lang["text_events"] = "Events";
$lang["text_auto"] = "Autos";
$lang["text_travel"] = "Travel";
$lang["text_feature"] = "Featured Adds";
$lang["text_all_feature"] = " View All  ";
$lang["text_swap_adds"] = "Swapping Adds";
$lang["text_all_swaping"] = " View All ";
$lang["text_recent_adds"] = " Recent Adds";
$lang["text_all_recent_adds"] = " View All ";
$lang["text_mostview_adds"] = " Most View Ads ";
$lang["text_all_mostview_adds"] = " View All ";
$lang["text_toprated"] = " Top Rated Ads";
$lang["text_all_toprated_adds"] = " View All ";
$lang["text_store"] = "Store";
$lang["text_information"] = "Informaiton";
$lang["text_con_categories"] = "Categories";



foreach($lang as $key => $val)
{
	$GLOBALS['language'][$key] = $val;
}


?>