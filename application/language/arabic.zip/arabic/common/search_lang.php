<?php


$lang["text_advsearch"] = 'Advanced Search';
$lang["text_allcities"] = 'All Cities';
$lang["text_allcategories"] = 'All Categories';
$lang["text_models"] = 'Models';
$lang["text_search"] = 'Search';

foreach($lang as $key => $val)
{
	$GLOBALS['language'][$key] = $val;
}


?>