<?php


$lang["text_product_empty"] = " There is no ads in this Category! ";

foreach($lang as $key => $val)
{
	$GLOBALS['language'][$key] = $val;
}


?>