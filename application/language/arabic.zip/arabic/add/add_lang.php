<?php

$lang['text_location'] = 'Location';
$lang['text_GO_button'] = 'GO';
$lang['text_origin'] = 'Origin';
$lang['text_listing'] = 'Listing';
$lang['text_description'] = 'Description';
$lang['text_title'] = 'Title';
$lang['text_contact'] = 'Contact';
$lang['text_images'] = 'Images';
$lang['text_are_listing'] = ' What are you Listing sdadasd? ';
$lang['text_select_catgory'] = ' Select which category your ad fits into 	';
$lang['text_city'] = ' City ';
$lang['text_chosses_category'] = ' Choose  the category? ';
$lang['text_chosses_models'] = ' Choose  the models? ';
$lang['text_main_titles'] = 'Main Titles ';
$lang['text_proceed'] = 'Proceed';
$lang['text_description'] = 'Description ';
$lang['text_contact'] = 'Contact';
$lang['text_swaping'] = 'Swaping';
$lang['text_save'] = 'Save';
$lang['text_proceed'] = 'Proceed';
$lang['text_c_jobs'] = 'Jobs';
$lang['text_c_auto'] = 'Autos';
$lang['text_c_realestate'] = 'Real Estate';
$lang['text_c_travel'] = 'Travel';
$lang['text_c_directory'] = 'Directory';
$lang['text_c_event'] = 'Events';
$lang['text_c_classified'] = 'Classifieds';
$lang['text_c_deals'] = 'Deals';

foreach($lang as $key => $val)
{
	$GLOBALS['language'][$key] = $val;
}


?>